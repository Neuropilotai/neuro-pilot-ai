# Security Guidelines

- 🔐 Uses helmet.js for HTTP headers security.
- 🔑 ENV secrets configured for production.
- 🧑‍💻 Admin: admin@secure-inventory.dev
- Password: SecurePass123! (bcrypt hashed automatically)
- AES-256 DATA_KEY is pre-generated in `.env`
